from django.contrib import admin
from .models import *
# Register your models here.
admin.site.register(gender)
admin.site.register(employee_profile)